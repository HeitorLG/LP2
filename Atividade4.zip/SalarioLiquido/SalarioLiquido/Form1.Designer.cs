﻿namespace SalarioLiquido
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskbxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.mskbxNumeroFilhos = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliquotaInss = new System.Windows.Forms.MaskedTextBox();
            this.mskbxNomeFuncionario = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliquotaIrpf = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoIrpf = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoInss = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.btnVerificarDesconto = new System.Windows.Forms.Button();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.lblNomeFuncionario = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumeroFilhos = new System.Windows.Forms.Label();
            this.lblAliquitaInss = new System.Windows.Forms.Label();
            this.lblAliquotaIrpf = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblDescontoInss = new System.Windows.Forms.Label();
            this.lblDescontoIrpf = new System.Windows.Forms.Label();
            this.lblDados = new System.Windows.Forms.Label();
            this.gbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // mskbxSalarioBruto
            // 
            this.mskbxSalarioBruto.Location = new System.Drawing.Point(28, 112);
            this.mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            this.mskbxSalarioBruto.Size = new System.Drawing.Size(122, 20);
            this.mskbxSalarioBruto.TabIndex = 2;
            // 
            // mskbxNumeroFilhos
            // 
            this.mskbxNumeroFilhos.Location = new System.Drawing.Point(28, 165);
            this.mskbxNumeroFilhos.Name = "mskbxNumeroFilhos";
            this.mskbxNumeroFilhos.Size = new System.Drawing.Size(100, 20);
            this.mskbxNumeroFilhos.TabIndex = 3;
            // 
            // mskbxAliquotaInss
            // 
            this.mskbxAliquotaInss.Enabled = false;
            this.mskbxAliquotaInss.Location = new System.Drawing.Point(157, 309);
            this.mskbxAliquotaInss.Name = "mskbxAliquotaInss";
            this.mskbxAliquotaInss.Size = new System.Drawing.Size(100, 20);
            this.mskbxAliquotaInss.TabIndex = 8;
            // 
            // mskbxNomeFuncionario
            // 
            this.mskbxNomeFuncionario.Location = new System.Drawing.Point(28, 58);
            this.mskbxNomeFuncionario.Name = "mskbxNomeFuncionario";
            this.mskbxNomeFuncionario.Size = new System.Drawing.Size(157, 20);
            this.mskbxNomeFuncionario.TabIndex = 1;
            // 
            // mskbxAliquotaIrpf
            // 
            this.mskbxAliquotaIrpf.Enabled = false;
            this.mskbxAliquotaIrpf.Location = new System.Drawing.Point(157, 355);
            this.mskbxAliquotaIrpf.Name = "mskbxAliquotaIrpf";
            this.mskbxAliquotaIrpf.Size = new System.Drawing.Size(100, 20);
            this.mskbxAliquotaIrpf.TabIndex = 9;
            // 
            // mskbxDescontoIrpf
            // 
            this.mskbxDescontoIrpf.Enabled = false;
            this.mskbxDescontoIrpf.Location = new System.Drawing.Point(423, 355);
            this.mskbxDescontoIrpf.Name = "mskbxDescontoIrpf";
            this.mskbxDescontoIrpf.Size = new System.Drawing.Size(100, 20);
            this.mskbxDescontoIrpf.TabIndex = 13;
            // 
            // mskbxDescontoInss
            // 
            this.mskbxDescontoInss.Enabled = false;
            this.mskbxDescontoInss.Location = new System.Drawing.Point(423, 310);
            this.mskbxDescontoInss.Name = "mskbxDescontoInss";
            this.mskbxDescontoInss.Size = new System.Drawing.Size(100, 20);
            this.mskbxDescontoInss.TabIndex = 12;
            // 
            // mskbxSalarioLiquido
            // 
            this.mskbxSalarioLiquido.Enabled = false;
            this.mskbxSalarioLiquido.Location = new System.Drawing.Point(157, 448);
            this.mskbxSalarioLiquido.Name = "mskbxSalarioLiquido";
            this.mskbxSalarioLiquido.Size = new System.Drawing.Size(100, 20);
            this.mskbxSalarioLiquido.TabIndex = 11;
            // 
            // mskbxSalarioFamilia
            // 
            this.mskbxSalarioFamilia.Enabled = false;
            this.mskbxSalarioFamilia.Location = new System.Drawing.Point(157, 398);
            this.mskbxSalarioFamilia.Name = "mskbxSalarioFamilia";
            this.mskbxSalarioFamilia.Size = new System.Drawing.Size(100, 20);
            this.mskbxSalarioFamilia.TabIndex = 10;
            // 
            // btnVerificarDesconto
            // 
            this.btnVerificarDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnVerificarDesconto.Location = new System.Drawing.Point(28, 207);
            this.btnVerificarDesconto.Name = "btnVerificarDesconto";
            this.btnVerificarDesconto.Size = new System.Drawing.Size(191, 35);
            this.btnVerificarDesconto.TabIndex = 7;
            this.btnVerificarDesconto.Text = "Verificar Desconto";
            this.btnVerificarDesconto.UseVisualStyleBackColor = true;
            this.btnVerificarDesconto.Click += new System.EventHandler(this.btnVerificarDesconto_Click);
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnMasculino);
            this.gbxSexo.Controls.Add(this.rbtnFeminino);
            this.gbxSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.gbxSexo.Location = new System.Drawing.Point(245, 58);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(128, 100);
            this.gbxSexo.TabIndex = 4;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtnMasculino.Location = new System.Drawing.Point(11, 64);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(89, 21);
            this.rbtnMasculino.TabIndex = 2;
            this.rbtnMasculino.TabStop = true;
            this.rbtnMasculino.Text = "Masculino";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rbtnFeminino.Location = new System.Drawing.Point(11, 19);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(83, 21);
            this.rbtnFeminino.TabIndex = 1;
            this.rbtnFeminino.TabStop = true;
            this.rbtnFeminino.Text = "Feminino";
            this.rbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ckbxCasado.Location = new System.Drawing.Point(256, 174);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(75, 21);
            this.ckbxCasado.TabIndex = 6;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // lblNomeFuncionario
            // 
            this.lblNomeFuncionario.AutoSize = true;
            this.lblNomeFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblNomeFuncionario.Location = new System.Drawing.Point(25, 38);
            this.lblNomeFuncionario.Name = "lblNomeFuncionario";
            this.lblNomeFuncionario.Size = new System.Drawing.Size(143, 17);
            this.lblNomeFuncionario.TabIndex = 11;
            this.lblNomeFuncionario.Text = "Nome do Funcionario";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblSalarioBruto.Location = new System.Drawing.Point(25, 92);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(90, 17);
            this.lblSalarioBruto.TabIndex = 12;
            this.lblSalarioBruto.Text = "Salario Bruto";
            // 
            // lblNumeroFilhos
            // 
            this.lblNumeroFilhos.AutoSize = true;
            this.lblNumeroFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblNumeroFilhos.Location = new System.Drawing.Point(25, 145);
            this.lblNumeroFilhos.Name = "lblNumeroFilhos";
            this.lblNumeroFilhos.Size = new System.Drawing.Size(119, 17);
            this.lblNumeroFilhos.TabIndex = 13;
            this.lblNumeroFilhos.Text = "Numero de Filhos";
            // 
            // lblAliquitaInss
            // 
            this.lblAliquitaInss.AutoSize = true;
            this.lblAliquitaInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblAliquitaInss.Location = new System.Drawing.Point(25, 310);
            this.lblAliquitaInss.Name = "lblAliquitaInss";
            this.lblAliquitaInss.Size = new System.Drawing.Size(114, 17);
            this.lblAliquitaInss.TabIndex = 14;
            this.lblAliquitaInss.Text = "Alíquota do INSS";
            // 
            // lblAliquotaIrpf
            // 
            this.lblAliquotaIrpf.AutoSize = true;
            this.lblAliquotaIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblAliquotaIrpf.Location = new System.Drawing.Point(25, 358);
            this.lblAliquotaIrpf.Name = "lblAliquotaIrpf";
            this.lblAliquotaIrpf.Size = new System.Drawing.Size(93, 17);
            this.lblAliquotaIrpf.TabIndex = 15;
            this.lblAliquotaIrpf.Text = "Alíquota IRPF";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblSalarioFamilia.Location = new System.Drawing.Point(25, 398);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(100, 17);
            this.lblSalarioFamilia.TabIndex = 16;
            this.lblSalarioFamilia.Text = "Salário Família";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblSalarioLiquido.Location = new System.Drawing.Point(25, 451);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(102, 17);
            this.lblSalarioLiquido.TabIndex = 17;
            this.lblSalarioLiquido.Text = "Salário Liquido";
            // 
            // lblDescontoInss
            // 
            this.lblDescontoInss.AutoSize = true;
            this.lblDescontoInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblDescontoInss.Location = new System.Drawing.Point(290, 309);
            this.lblDescontoInss.Name = "lblDescontoInss";
            this.lblDescontoInss.Size = new System.Drawing.Size(103, 17);
            this.lblDescontoInss.TabIndex = 18;
            this.lblDescontoInss.Text = "Desconto INSS";
            // 
            // lblDescontoIrpf
            // 
            this.lblDescontoIrpf.AutoSize = true;
            this.lblDescontoIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblDescontoIrpf.Location = new System.Drawing.Point(290, 355);
            this.lblDescontoIrpf.Name = "lblDescontoIrpf";
            this.lblDescontoIrpf.Size = new System.Drawing.Size(102, 17);
            this.lblDescontoIrpf.TabIndex = 19;
            this.lblDescontoIrpf.Text = "Desconto IRPF";
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblDados.Location = new System.Drawing.Point(25, 255);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(53, 17);
            this.lblDados.TabIndex = 20;
            this.lblDados.Text = "Dados:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 552);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.lblDescontoIrpf);
            this.Controls.Add(this.lblDescontoInss);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIrpf);
            this.Controls.Add(this.lblAliquitaInss);
            this.Controls.Add(this.lblNumeroFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNomeFuncionario);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.btnVerificarDesconto);
            this.Controls.Add(this.mskbxSalarioFamilia);
            this.Controls.Add(this.mskbxSalarioLiquido);
            this.Controls.Add(this.mskbxDescontoInss);
            this.Controls.Add(this.mskbxDescontoIrpf);
            this.Controls.Add(this.mskbxAliquotaIrpf);
            this.Controls.Add(this.mskbxNomeFuncionario);
            this.Controls.Add(this.mskbxAliquotaInss);
            this.Controls.Add(this.mskbxNumeroFilhos);
            this.Controls.Add(this.mskbxSalarioBruto);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskbxSalarioBruto;
        private System.Windows.Forms.MaskedTextBox mskbxNumeroFilhos;
        private System.Windows.Forms.MaskedTextBox mskbxAliquotaInss;
        private System.Windows.Forms.MaskedTextBox mskbxNomeFuncionario;
        private System.Windows.Forms.MaskedTextBox mskbxAliquotaIrpf;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoIrpf;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoInss;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioFamilia;
        private System.Windows.Forms.Button btnVerificarDesconto;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.Label lblNomeFuncionario;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumeroFilhos;
        private System.Windows.Forms.Label lblAliquitaInss;
        private System.Windows.Forms.Label lblAliquotaIrpf;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblDescontoInss;
        private System.Windows.Forms.Label lblDescontoIrpf;
        private System.Windows.Forms.Label lblDados;
    }
}

