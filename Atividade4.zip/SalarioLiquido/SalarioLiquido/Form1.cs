﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalarioLiquido
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificarDesconto_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0, descontoIRPF = 0, salarioFamilia = 0;
            double salarioBruto = 0, salarioLiquido = 0, quantidadeFilhos = 0;

            if ((double.TryParse(mskbxSalarioBruto.Text, out salarioBruto)) &&
            (double.TryParse(mskbxNumeroFilhos.Text, out quantidadeFilhos)))
            {
                if (rbtnMasculino.Checked || rbtnFeminino.Checked)
                {
                    if (salarioBruto <= 800.47)
                    {
                        mskbxAliquotaInss.Text = "7.65%";
                        descontoINSS = salarioBruto * (7.65 / 100);

                        if (salarioBruto <= 435.52)
                        {
                            salarioFamilia = (22.33 * quantidadeFilhos);
                        }

                        else if (salarioBruto > 435.52 && salarioBruto < 654.61)
                        {
                            salarioFamilia = (15.74 * quantidadeFilhos);
                        }

                        else if (salarioBruto > 654.61)
                        {
                            salarioFamilia = 0;
                        }
                    }

                    else if (salarioBruto <= 1050)
                    {
                        mskbxAliquotaInss.Text = "8.65%";
                        descontoINSS = salarioBruto * (8.65 / 100);
                    }

                    else if (salarioBruto <= 1400.77)
                    {
                        mskbxAliquotaInss.Text = "9.00%";
                        descontoINSS = salarioBruto * (9.00 / 100);
                    }

                    else if (salarioBruto <= 2801.56)
                    {
                        mskbxAliquotaInss.Text = "11.00%";
                        descontoINSS = salarioBruto * (11.00 / 100);
                    }

                    else if (salarioBruto > 2801.56)
                    {
                        mskbxAliquotaInss.Text = "308.17";
                        descontoINSS = 308.17;
                    }

                    if (salarioBruto < 1257.12)
                    {
                        mskbxAliquotaIrpf.Text = "0,00";
                    }
                    else if (salarioBruto > 1257.12 && salarioBruto <= 2512.08)
                    {
                        mskbxAliquotaIrpf.Text = "15,00%";
                        descontoIRPF = salarioBruto * 0.15;
                    }

                    else if (salarioBruto > 2512.08)
                    {
                        mskbxAliquotaIrpf.Text = "27.5%";
                        descontoIRPF = salarioBruto * 0.275;
                    }

                    if (ckbxCasado.Checked)
                    {
                        lblDados.Text = "O descontos do salário do(a) "
                       + mskbxNomeFuncionario.Text + "\nque é casado(a) e que tem "
                       + mskbxNumeroFilhos.Text + " filho(s) são:";
                    }
                    else
                    {
                        lblDados.Text = "O descontos do salário do(a) "
                          + mskbxNomeFuncionario.Text + "\nque é solteiro(a) e que tem "
                          + mskbxNumeroFilhos.Text + " filho(s) são:";
                    }

                    salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                    mskbxSalarioLiquido.Text = salarioLiquido.ToString("N2");
                    mskbxSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    mskbxDescontoInss.Text = descontoINSS.ToString("N2");
                    mskbxDescontoIrpf.Text = descontoIRPF.ToString("N2");


                }
                else
                    MessageBox.Show("Seleciona o sexo");
            }
            else
                MessageBox.Show("Preencha os dados");
        }
    }
}
