﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TipoTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double ladoA, ladoB, ladoC;



            if (double.TryParse(mskbxLadoA.Text, out ladoA) &&
                double.TryParse(mskbxLadoB.Text, out ladoB) &&
                double.TryParse(mskbxLadoC.Text, out ladoC))
            {
                if (ladoA > 0 && ladoB > 0 && ladoC > 0)
                {

                    if (((ladoB - ladoC) < ladoA && ladoA < (ladoB + ladoC)) &&
                        ((ladoA - ladoC) < ladoB && ladoB < (ladoA + ladoC)) &&
                        ((ladoA - ladoB) < ladoC && ladoC < (ladoA + ladoB)))
                    {
                        if (ladoA == ladoB && ladoB == ladoC)
                            MessageBox.Show("Triângulo Equilátero");

                        else if ((ladoA == ladoB && ladoB != ladoC) ||
                            (ladoC == ladoB && ladoA != ladoC) ||
                            (ladoA == ladoC && ladoA != ladoB))
                            MessageBox.Show("Triângulo Isósceles");


                        else if (ladoA != ladoB && ladoB != ladoC)
                            MessageBox.Show("Triângulo Escaleno");
                    }

                    else
                        MessageBox.Show("Os valores não pertencem a um triângulo");
                }
                else
                    MessageBox.Show("O valor deve ser maior que zero");
            }

            else
                MessageBox.Show("Digita um valor numerico");
        }
    }
}
