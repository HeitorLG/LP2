﻿namespace TipoTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskbxLadoC = new System.Windows.Forms.MaskedTextBox();
            this.mskbxLadoB = new System.Windows.Forms.MaskedTextBox();
            this.mskbxLadoA = new System.Windows.Forms.MaskedTextBox();
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mskbxLadoC
            // 
            this.mskbxLadoC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.mskbxLadoC.Location = new System.Drawing.Point(91, 139);
            this.mskbxLadoC.Name = "mskbxLadoC";
            this.mskbxLadoC.Size = new System.Drawing.Size(100, 23);
            this.mskbxLadoC.TabIndex = 3;
            // 
            // mskbxLadoB
            // 
            this.mskbxLadoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.mskbxLadoB.Location = new System.Drawing.Point(91, 82);
            this.mskbxLadoB.Name = "mskbxLadoB";
            this.mskbxLadoB.Size = new System.Drawing.Size(100, 23);
            this.mskbxLadoB.TabIndex = 2;
            // 
            // mskbxLadoA
            // 
            this.mskbxLadoA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.mskbxLadoA.Location = new System.Drawing.Point(91, 25);
            this.mskbxLadoA.Name = "mskbxLadoA";
            this.mskbxLadoA.Size = new System.Drawing.Size(100, 23);
            this.mskbxLadoA.TabIndex = 1;
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblA.Location = new System.Drawing.Point(30, 25);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(17, 17);
            this.lblA.TabIndex = 3;
            this.lblA.Text = "A";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblB.Location = new System.Drawing.Point(30, 85);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(17, 17);
            this.lblB.TabIndex = 4;
            this.lblB.Text = "B";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblC.Location = new System.Drawing.Point(30, 146);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(17, 17);
            this.lblC.TabIndex = 5;
            this.lblC.Text = "C";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.btnVerificar.Location = new System.Drawing.Point(91, 197);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(100, 50);
            this.btnVerificar.TabIndex = 4;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(254, 289);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.mskbxLadoA);
            this.Controls.Add(this.mskbxLadoB);
            this.Controls.Add(this.mskbxLadoC);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskbxLadoC;
        private System.Windows.Forms.MaskedTextBox mskbxLadoB;
        private System.Windows.Forms.MaskedTextBox mskbxLadoA;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Button btnVerificar;
    }
}

