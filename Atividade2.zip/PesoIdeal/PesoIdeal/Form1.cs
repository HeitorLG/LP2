﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double altura, pesoAtual, pesoIdeal;

            if ((double.TryParse(mskbxAltura.Text, out altura)) &&
            (double.TryParse(mskbxPesoAtual.Text, out pesoAtual)))
            {

                if (rbtnMasculino.Checked)
                {
                    pesoIdeal = (altura * 72.7) - 58;
                    pesoIdeal = Math.Round(pesoIdeal, 2);

                    if (pesoAtual == pesoIdeal)
                        MessageBox.Show("Você está com o peso ideal");
                    if (pesoAtual > pesoIdeal)
                        MessageBox.Show("Você está acima do seu peso ideal");
                    if (pesoAtual < pesoIdeal)
                        MessageBox.Show("Você está abaixo do seu peso ideal");
                }

                else if (rbtnFeminino.Checked)
                {
                    pesoIdeal = (altura * 62.1) - 44.7;
                    pesoIdeal = Math.Round(pesoIdeal, 2);

                    if (pesoAtual == pesoIdeal)
                        MessageBox.Show("Você está com seu peso ideal");
                    if (pesoAtual > pesoIdeal)
                        MessageBox.Show("Você está acima do seu peso ideal");
                    if (pesoAtual < pesoIdeal)
                        MessageBox.Show("Você está abaixo do seu peso ideal");
                }

                else
                    MessageBox.Show("Escolha o sexo!!");
            }
            else
                MessageBox.Show("Dados Invalidos!!");
        }
    }
}
